package Giai_Cuu_He_Thong_Ban_Ve_MegaCine;

/**
 * ============================================================
 *  HE THONG BAN VE MEGACINE
 *  File nay chua CA HAI phien ban de doi chieu:
 *    1) TicketPricingServiceLegacy    - code goc, nhieu tang if long nhau
 *    2) TicketPricingServiceRefactored - code sau khi ap dung Guard Clauses
 *  main() se chay tu dong nhieu bo du lieu test, so sanh 2 ket qua.
 * ============================================================
 */
public class TicketPricingSystem {

    // ============================================================
    // 1) PHIEN BAN LEGACY (giu nguyen, khong sua, chi de doi chieu)
    // ============================================================
    static class TicketPricingServiceLegacy {
        public double calculatePrice(int age, String dayOfWeek, boolean isMember) {
            double basePrice = 100000;
            double finalPrice = 0;

            if (age > 0) {
                if (dayOfWeek != null && !dayOfWeek.isEmpty()) {
                    if (dayOfWeek.equalsIgnoreCase("Tuesday")) {
                        finalPrice = basePrice * 0.5; // Happy Day 50%
                    } else {
                        if (age <= 12) {
                            if (isMember) {
                                finalPrice = (basePrice * 0.7) - 10000; // Tre em + VIP
                            } else {
                                finalPrice = basePrice * 0.7; // Tre em
                            }
                        } else if (age >= 60) {
                            finalPrice = basePrice * 0.6; // Nguoi cao tuoi
                        } else {
                            if (dayOfWeek.equalsIgnoreCase("Saturday") || dayOfWeek.equalsIgnoreCase("Sunday")) {
                                if (isMember) {
                                    finalPrice = (basePrice * 1.2) * 0.9; // Cuoi tuan + VIP
                                } else {
                                    finalPrice = basePrice * 1.2; // Cuoi tuan
                                }
                            } else {
                                if (isMember) {
                                    finalPrice = basePrice * 0.9; // Ngay thuong + VIP
                                } else {
                                    finalPrice = basePrice;
                                }
                            }
                        }
                    }
                } else {
                    return -1; // Loi ngay
                }
            } else {
                return -1; // Loi tuoi
            }

            return finalPrice;
        }
    }

    // ============================================================
    // 2) PHIEN BAN REFACTORED (Guard Clauses, tach ham, giam tang long)
    // ============================================================
    static class TicketPricingServiceRefactored {

        private static final double BASE_PRICE = 100000;

        public double finalPrice(int age, String dayOfWeek, boolean isMember) {
            // Guard clause: chan het cac truong hop du lieu khong hop le ngay dau ham
            if (age <= 0 || dayOfWeek == null || dayOfWeek.isBlank()) {
                return -1;
            }

            // Truong hop dac biet: thu Ba luon dong gia 50%, khong phu thuoc tuoi/thanh vien
            if (dayOfWeek.equalsIgnoreCase("Tuesday")) {
                return BASE_PRICE * 0.5;
            }

            // Cac ngay con lai: tinh theo do tuoi
            return tinhGiaTheoDoTuoi(age, dayOfWeek, isMember);
        }

        private double tinhGiaTheoDoTuoi(int age, String dayOfWeek, boolean isMember) {
            if (age <= 12) {
                return isMember ? (BASE_PRICE * 0.7) - 10000 : BASE_PRICE * 0.7;
            }
            if (age >= 60) {
                return BASE_PRICE * 0.6;
            }
            // Nguoi lon binh thuong: tach tiep sang ham rieng de khong long qua 2 tang
            return tinhGiaNguoiLon(dayOfWeek, isMember);
        }

        private double tinhGiaNguoiLon(String dayOfWeek, boolean isMember) {
            boolean laCuoiTuan = dayOfWeek.equalsIgnoreCase("Saturday")
                    || dayOfWeek.equalsIgnoreCase("Sunday");

            if (laCuoiTuan) {
                return isMember ? (BASE_PRICE * 1.2) * 0.9 : BASE_PRICE * 1.2;
            }
            return isMember ? BASE_PRICE * 0.9 : BASE_PRICE;
        }
    }

    // ============================================================
    // 3) MAIN - chay test doi chieu 2 phien ban
    // ============================================================
    public static void main(String[] args) {
        TicketPricingServiceLegacy legacy = new TicketPricingServiceLegacy();
        TicketPricingServiceRefactored refactored = new TicketPricingServiceRefactored();

        Object[][] testCases = {
                // age, dayOfWeek, isMember
                {-5, "Monday", false},
                {10, null, false},
                {20, "Tuesday", true},
                {10, "Monday", true},
                {10, "Monday", false},
                {65, "Friday", true},
                {30, "Saturday", true},
                {30, "Sunday", false},
                {30, "Monday", true},
                {30, "Monday", false},
        };

        System.out.println("So sanh Legacy vs Refactored");
        System.out.println("--------------------------------------------------------");
        int soCaDung = 0;

        for (Object[] tc : testCases) {
            int age = (int) tc[0];
            String day = (String) tc[1];
            boolean member = (boolean) tc[2];

            double giaLegacy = legacy.calculatePrice(age, day, member);
            double giaMoi = refactored.finalPrice(age, day, member);

            boolean khop = Double.compare(giaLegacy, giaMoi) == 0;
            if (khop) {
                soCaDung++;
            }

            System.out.printf(
                    "age=%-4d day=%-9s member=%-5b | Legacy=%-10.1f Refactored=%-10.1f %s%n",
                    age, day, member, giaLegacy, giaMoi, khop ? "OK" : "SAI LECH"
            );
        }

        System.out.println("--------------------------------------------------------");
        System.out.println("Ket qua: " + soCaDung + "/" + testCases.length + " test case khop nhau.");
    }
}
