# Branching Analysis — TicketPricingService

**Trước refactor (Legacy):** toàn bộ logic nằm trong 1 phương thức `calculatePrice()`,
lồng tới 5-6 tầng if-else. Đếm số điểm quyết định (if / else if / && / ||) + 1:
**Cyclomatic Complexity ≈ 12**.

**Sau refactor:** tách thành 3 phương thức nhỏ theo nguyên tắc Guard Clauses
(`finalPrice`, `tinhGiaTheoDoTuoi`, `tinhGiaNguoiLon`), mỗi phương thức chỉ xử lý
đúng 1 nhóm điều kiện, tối đa 2 tầng lồng:

- `finalPrice()`: CC ≈ 5 (guard clause + case Tuesday)
- `tinhGiaTheoDoTuoi()`: CC ≈ 5 (tuổi trẻ em/già + gọi hàm phụ)
- `tinhGiaNguoiLon()`: CC ≈ 4 (cuối tuần + thành viên)

**Kết quả:** độ phức tạp cao nhất trên 1 phương thức giảm từ **12 xuống còn 5**
(giảm ~58%). Hành vi đầu ra được giữ nguyên 100%, kiểm chứng bằng 10 test case
đối chiếu trực tiếp giữa 2 phiên bản trong `main()`.
