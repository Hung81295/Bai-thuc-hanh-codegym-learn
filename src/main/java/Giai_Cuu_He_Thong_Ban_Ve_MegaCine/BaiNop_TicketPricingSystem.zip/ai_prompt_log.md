# AI Prompt Log — Bài refactor TicketPricingService

## Prompt 1
**Hỏi:** Giải thích cách hoạt động của Switch Expression trong Java mới
(toán tử `->` và từ khóa `yield`), khác gì so với switch-case cũ.
**Mục đích:** Tìm hiểu cú pháp mới trước khi quyết định có dùng cho phần
phân loại `dayOfWeek` hay không.
**Kết quả áp dụng:** Không dùng switch expression trong bản nộp cuối vì chỉ
có 1 điều kiện đặc biệt (Tuesday) cần tách riêng, dùng `if` đơn giản hơn.

## Prompt 2
**Hỏi:** Giải thích khái niệm "Guard Clauses" và "Arrow Anti-Pattern" —
vì sao code lồng nhiều tầng if-else lại là vấn đề, cách khắc phục.
**Mục đích:** Hiểu cơ chế trước khi tự viết lại hàm `calculatePrice()`.
**Kết quả áp dụng:** Tự viết Guard Clause chặn `age <= 0` / `dayOfWeek`
không hợp lệ ngay đầu hàm `finalPrice()`, và tự tách logic thành 3 hàm
(`finalPrice`, `tinhGiaTheoDoTuoi`, `tinhGiaNguoiLon`) để giảm số tầng lồng.

## Prompt 3
**Hỏi:** Giải thích ý nghĩa dòng `dayOfWeek.equalsIgnoreCase("Saturday")
|| dayOfWeek.equalsIgnoreCase("Sunday")` trong code gốc — vì sao cuối tuần
gồm cả 2 ngày.
**Mục đích:** Tự phát hiện lỗi thiếu điều kiện "Sunday" trong bản refactor
đầu tiên của mình (chỉ kiểm tra Saturday), do đọc sót logic gốc.
**Kết quả áp dụng:** Tự sửa lại điều kiện, kiểm chứng bằng test case
`finalPrice(30, "Sunday", false)` phải ra 120000.

## Lưu ý tuân thủ quy định
- Không yêu cầu AI "sửa lại đoạn code cho chạy đúng" ở bất kỳ prompt nào —
  AI chỉ giải thích cơ chế lỗi (biến trả về sai, thiếu return sớm, thiếu
  điều kiện Sunday), người học tự tay sửa và tự kiểm chứng lại bằng test case.
- Toàn bộ code Refactored trong `TicketPricingSystem.java` do người học tự
  viết qua nhiều lượt sửa, có ghi lại đầy đủ trong lịch sử hội thoại gốc.
